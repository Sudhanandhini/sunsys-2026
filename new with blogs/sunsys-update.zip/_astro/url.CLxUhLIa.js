const t="/".replace(/\/$/,""),r=s=>s.startsWith("/")&&!s.startsWith("//")?t+s:s;export{r as u};
